---
title: "Layout: Header Image (Vertical)"
header:
  image: /assets/images/unsplash-image-6.jpg
  caption: "Photo credit: [**Unsplash**](https://unsplash.com)"
categories:
  - Layout
  - Uncategorized
tags:
  - edge case
  - featured image
  - image
  - layout
---

This post should display a **header image**, if the theme supports it.

Non-square images can provide some unique styling issues.

This post tests a vertical header image.